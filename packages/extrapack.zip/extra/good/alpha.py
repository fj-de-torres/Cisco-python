def funA():
    pass