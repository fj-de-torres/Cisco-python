def funS():
    pass