def funT():
    pass