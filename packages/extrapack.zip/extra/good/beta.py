def funB():
    pass