def funI():
    pass